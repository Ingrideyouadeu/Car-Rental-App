package com.example.carrentalapp.states.car;

public enum CarAvailabilityState {
    AVAILABLE,
    UNAVAILABLE
}
