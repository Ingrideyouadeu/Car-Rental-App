package com.example.carrentalapp.states.contract;

public enum ContractState {
    ACTIVE,
    CANCELED,
    COMPLETED
}
